package com.example.meetfinance;

import android.os.Bundle;

public class RestDetailsResponse {
    private String symbol2;
    private Double price;
    private Bundle symbolSent;


    public String getSymbol2() {
        return symbol2;
    }

    public Double getPrice() {
        return price;
    }
}
