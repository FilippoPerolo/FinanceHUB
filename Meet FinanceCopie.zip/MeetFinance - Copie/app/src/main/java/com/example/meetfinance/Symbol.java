package com.example.meetfinance;

public class Symbol {
    private String symbol;
    private String name;
    private float price;
    private String exchange;

    public String getSymbol() {
        return symbol;
    }

    public String getName() {
        return name;
    }

    public float getPrice() {
        return price;
    }

    public String getExchange() {
        return exchange;
    }
}
