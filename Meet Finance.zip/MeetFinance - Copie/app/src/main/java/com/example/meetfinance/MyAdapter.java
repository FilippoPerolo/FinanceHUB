package com.example.meetfinance;

import android.content.Context;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter {
    private Context context;
    private List<String> data;

    public MyAdapter(Context context, List<String> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      /*  View itemView = LayoutInflater.from(context).inflate(R.layout.example_row, parent, false);
        return new MyViewHolder(itemView); */
      return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        String item = data.get(position);
        ((MyViewHolder) holder).textView.setText(item);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;
        protected TextureView textureView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
          //  textureView = itemView.findViewById(R.id.rv_example_data);
        }
    }
}
