package com.example.meetfinance;

public class Constants {
    static String KEY_SYMBOLS_LIST = "jsonSymbolsList";
}
