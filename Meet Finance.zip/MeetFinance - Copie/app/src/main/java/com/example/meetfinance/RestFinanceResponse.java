package com.example.meetfinance;

import java.util.List;

public class RestFinanceResponse {
    private List<Symbol> symbolsList;

    public List<Symbol> getSymbolsList() {
        return symbolsList;
    }
}
